#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = path.resolve(new URL('.', import.meta.url).pathname, '..');
const DATA_PATH = path.join(ROOT, 'data', 'stores.json');
const SOURCES_PATH = path.join(ROOT, 'data', 'source-registry.json');
const REPORT_PATH = path.join(ROOT, 'data', 'update-report.json');
const today = new Date();
const checkedAt = today.toISOString();
const checkedDate = checkedAt.slice(0, 10);

const REQUEST_HEADERS = {
  'user-agent': 'OpenTodayAlicanteDataBot/1.0 (+https://open-today-alicante.com/data-policy)',
  'accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.7',
  'accept-language': 'es-ES,es;q=0.9,en;q=0.7'
};

function normalizeText(value = '') {
  return value.toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

function htmlToText(html = '') {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractJsonLd(html = '') {
  const out = [];
  const re = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(html))) {
    try {
      const json = JSON.parse(m[1].trim());
      if (Array.isArray(json)) out.push(...json);
      else out.push(json);
    } catch (_) {
      // Some sites embed non-standard JSON-LD; ignore rather than fail the run.
    }
  }
  return out;
}

function flattenLd(item) {
  const result = [];
  const walk = value => {
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) return value.forEach(walk);
    result.push(value);
    if (value['@graph']) walk(value['@graph']);
    if (value.itemListElement) walk(value.itemListElement);
    if (value.mainEntity) walk(value.mainEntity);
    if (value.mainEntityOfPage) walk(value.mainEntityOfPage);
  };
  walk(item);
  return result;
}

function findBusinessJsonLd(ldObjects, store) {
  const targetName = normalizeText(store.name);
  const targetAddress = normalizeText(store.address).split(' ').filter(Boolean).slice(0, 5).join(' ');
  const candidates = ldObjects.flatMap(flattenLd).filter(x => typeof x === 'object');
  let best = null;
  let bestScore = 0;
  for (const obj of candidates) {
    const type = Array.isArray(obj['@type']) ? obj['@type'].join(' ') : (obj['@type'] || '');
    const name = normalizeText(obj.name || '');
    const address = normalizeText(typeof obj.address === 'object' ? Object.values(obj.address).join(' ') : (obj.address || ''));
    let score = 0;
    if (/localbusiness|store|pharmacy|gasstation|bakery|shoppingcenter|veterinary/i.test(type)) score += 2;
    if (name && (name === targetName || name.includes(targetName) || targetName.includes(name))) score += 6;
    if (targetAddress && address && address.includes(targetAddress)) score += 3;
    if (obj.openingHoursSpecification || obj.openingHours) score += 3;
    if (obj.telephone) score += 1;
    if (obj.geo) score += 1;
    if (score > bestScore) { bestScore = score; best = obj; }
  }
  return bestScore >= 5 ? best : null;
}

function dayNumber(day) {
  const map = {
    sunday: '0', monday: '1', tuesday: '2', wednesday: '3', thursday: '4', friday: '5', saturday: '6'
  };
  return map[normalizeText(day)] ?? null;
}

function hoursToWeeklyHours(business) {
  const result = {};
  const specs = business?.openingHoursSpecification;
  if (Array.isArray(specs)) {
    for (const spec of specs) {
      const days = Array.isArray(spec.dayOfWeek) ? spec.dayOfWeek : [spec.dayOfWeek];
      for (const day of days) {
        const key = dayNumber(typeof day === 'string' ? day : day?.name || '');
        if (key == null || !spec.opens || !spec.closes) continue;
        const [oh, om] = String(spec.opens).split(':').map(Number);
        const [ch, cm] = String(spec.closes).split(':').map(Number);
        if ([oh, om, ch, cm].every(Number.isFinite)) result[key] = [oh + om / 60, ch + cm / 60];
      }
    }
  }
  if (Object.keys(result).length) return result;

  const raw = business?.openingHours;
  if (Array.isArray(raw)) {
    for (const line of raw) {
      const m = String(line).match(/^(Mo|Tu|We|Th|Fr|Sa|Su)\s+(\d{2}):(\d{2})-(\d{2}):(\d{2})$/i);
      if (!m) continue;
      const shortDay = m[1].toLowerCase();
      const key = { su: '0', mo: '1', tu: '2', we: '3', th: '4', fr: '5', sa: '6' }[shortDay.slice(0,2)];
      if (!key) continue;
      result[key] = [Number(m[2]) + Number(m[3]) / 60, Number(m[4]) + Number(m[5]) / 60];
    }
  }
  return result;
}

function applyBusinessData(store, business) {
  let changed = false;
  const weekly = hoursToWeeklyHours(business);
  if (Object.keys(weekly).length >= 2) {
    store.weeklyHours = { ...(store.weeklyHours || {}), ...weekly };
    const monday = weekly['1'];
    const sunday = weekly['0'];
    if (monday) { store.weekOpenHour = monday[0]; store.weekCloseHour = monday[1]; }
    if (sunday) { store.sunOpenHour = sunday[0]; store.sunCloseHour = sunday[1]; store.isSundayOpen = true; }
    else if ('0' in weekly) { store.sunOpenHour = null; store.sunCloseHour = null; store.isSundayOpen = false; }
    store.hoursVerified = true;
    store.hoursStatus = 'checked';
    store.lastVerified = checkedDate;
    store.verification = {
      ...(store.verification || {}),
      verifiedAt: checkedDate,
      hoursVerified: true,
      status: 'official-locator',
      sourceUrl: store.sourceUrl || store.verification?.sourceUrl || null,
      sourceName: store.verification?.sourceName || store.officialSource || 'Official source'
    };
    changed = true;
  }

  if (business.telephone && !store.phone) {
    store.phone = String(business.telephone);
    changed = true;
  }
  if (business.address && !store.address) {
    const addr = typeof business.address === 'object' ? Object.values(business.address).join(', ') : String(business.address);
    if (addr) { store.address = addr; changed = true; }
  }
  if (business.geo) {
    const lat = Number(business.geo.latitude);
    const lng = Number(business.geo.longitude);
    if (Number.isFinite(lat) && Number.isFinite(lng) && (store.lat == null || store.lng == null)) {
      store.lat = lat; store.lng = lng; store.locationStatus = 'mapped'; changed = true;
    }
  }
  return changed;
}

async function fetchText(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(url, { headers: REQUEST_HEADERS, redirect: 'follow', signal: controller.signal });
    const body = await response.text();
    return { ok: response.ok, status: response.status, body, finalUrl: response.url };
  } finally { clearTimeout(timer); }
}

async function main() {
  const stores = JSON.parse(await fs.readFile(DATA_PATH, 'utf8'));
  const sources = JSON.parse(await fs.readFile(SOURCES_PATH, 'utf8'));
  const sourceById = new Map(sources.map(s => [s.id, s]));

  const report = {
    version: '10.0.0', checkedAt, checkedDate,
    sources: [],
    totals: { stores: stores.length, checked: 0, matched: 0, hoursUpdated: 0, flagged: 0, failed: 0 },
    notes: [
      'Conservative updater: only changes hours when an exact/strong structured-data match is found.',
      'A reachable source without parseable store data is recorded as checked but does not overwrite existing hours.',
      'No Google Maps scraping is used.'
    ]
  };

  const sourceCache = new Map();
  const changedIds = new Set();

  for (const source of sources) {
    try {
      const result = await fetchText(source.url);
      const ld = extractJsonLd(result.body);
      sourceCache.set(source.url, { result, ld, text: htmlToText(result.body) });
      report.sources.push({ id: source.id, url: source.url, ok: result.ok, status: result.status, finalUrl: result.finalUrl, jsonLdObjects: ld.length });
    } catch (error) {
      sourceCache.set(source.url, { error: error.message });
      report.sources.push({ id: source.id, url: source.url, ok: false, error: error.message });
      report.totals.failed += 1;
    }
  }

  for (const store of stores) {
    const sourceUrl = store.sourceUrl || store.verification?.sourceUrl;
    const source = sourceUrl ? (sources.find(s => sourceUrl === s.url) || { id: `store-source:${store.id}`, url: sourceUrl, type: 'store-source', scope: store.name, checkHours: true }) : null;
    let cache = sourceUrl ? sourceCache.get(sourceUrl) : null;
    if (sourceUrl && !cache) {
      try {
        const fetched = await fetchText(sourceUrl);
        cache = { result: fetched, ld: extractJsonLd(fetched.body), text: htmlToText(fetched.body) };
        sourceCache.set(sourceUrl, cache);
      } catch (error) {
        cache = { error: error.message };
        sourceCache.set(sourceUrl, cache);
      }
    }
    if (!cache || cache.error) {
      store.automation = { ...(store.automation || {}), lastCheckedAt: checkedAt, checkStatus: 'source-unreachable', sourceMatch: 'not-checked' };
      report.totals.flagged += 1;
      continue;
    }

    report.totals.checked += 1;
    const business = findBusinessJsonLd(cache.ld, store);
    let matched = false;
    let hoursUpdated = false;

    if (business) {
      matched = true;
      report.totals.matched += 1;
      hoursUpdated = applyBusinessData(store, business);
      if (hoursUpdated) { report.totals.hoursUpdated += 1; changedIds.add(store.id); }
    } else {
      const haystack = normalizeText(cache.text);
      const needle = normalizeText(store.name);
      const addressNeedle = normalizeText(store.address).split(' ').slice(0, 4).join(' ');
      matched = Boolean(needle && haystack.includes(needle)) || Boolean(addressNeedle && haystack.includes(addressNeedle));
    }

    store.automation = {
      ...(store.automation || {}),
      lastCheckedAt: checkedAt,
      checkStatus: cache.result.ok ? (matched ? 'checked' : 'source-reachable-no-match') : `http-${cache.result.status}`,
      sourceMatch: matched ? 'matched' : 'not-matched',
      sourceId: source?.id || null
    };
    if (!matched || (!hoursUpdated && source?.checkHours)) report.totals.flagged += 1;
  }

  const reportDigest = crypto.createHash('sha256').update(JSON.stringify(stores)).digest('hex');
  report.dataDigest = reportDigest;
  report.totals.changedStores = changedIds.size;

  await fs.writeFile(DATA_PATH, JSON.stringify(stores, null, 2) + '\n');
  await fs.writeFile(REPORT_PATH, JSON.stringify(report, null, 2) + '\n');

  console.log(JSON.stringify(report.totals, null, 2));
}

main().catch(error => { console.error(error); process.exit(1); });
